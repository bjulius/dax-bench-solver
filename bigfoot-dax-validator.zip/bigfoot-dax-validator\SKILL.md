---
name: Bigfoot DAX Validator
description: >
  This skill calculates ground-truth answers for 10 complex DAX patterns using the
  Bigfoot sightings dataset. Use this skill when verifying Power BI DAX measures,
  debugging DAX calculations that return unexpected results, or when the user asks
  "what should this DAX measure return?" The skill uses Python/Pandas to compute
  the same calculations that are difficult in DAX: consecutive streaks, gap detection,
  running distinct counts, previous non-blank values, Nth rankings, Pareto analysis,
  year-over-year comparisons, reset running totals, threshold dates, and median by group.
---

# Bigfoot DAX Validator

Calculate correct answers for complex DAX patterns using the BFRO Bigfoot Sightings dataset.

## Purpose

This skill provides "ground truth" calculations for 10 DAX patterns that are notoriously
difficult to implement correctly. When a user's DAX measure returns unexpected results,
run the equivalent Python calculation to determine what the correct answer should be.

**Core principle:** If Python and DAX produce the same answer, the DAX is likely correct.
If they differ, the user knows exactly which calculation to debug.

## When to Use This Skill

- User asks to verify a DAX calculation result
- User wants to check if their Power BI measure is returning correct values
- User asks "what should [metric] be?" for any of the 10 patterns
- User is debugging a DAX measure that returns unexpected results
- User mentions "Bigfoot" and "DAX" or "Power BI" together
- User asks about consecutive streaks, gap detection, running totals, or Pareto analysis

## Dataset Location

The Bigfoot sightings data should be at:
`C:/Users/brjul/OneDrive/Documents/Projects/WastesOfTime/bfro_reports_geocoded.csv`

If not found, prompt the user to provide the path to their `bfro_reports_geocoded.csv` file.

## Available Calculations

### The 10 "Easy to See, Hard to DAX" Patterns

| # | Calculation | Python Function | What It Computes |
|---|-------------|-----------------|------------------|
| 1 | Consecutive Streak | `longest_streak()` | Longest run of consecutive days with sightings |
| 2 | Gap Detection | `missing_report_numbers()` | Missing report numbers in the sequence |
| 3 | Running Distinct | `cumulative_unique_counties()` | Cumulative unique counties over time |
| 4 | Last Known Value | `last_known_temperature()` | Temperature, or last known if missing |
| 5 | Nth Highest | `nth_highest_state()` | State with Nth most sightings |
| 6 | Pareto 80% | `pareto_states()` | States accounting for 80% of sightings |
| 7 | YoY Comparison | `yoy_change()` | Year-over-year change in sightings |
| 8 | Reset Running Total | `cumulative_reset_by_period()` | Cumulative by decade/year with reset |
| 9 | Threshold Date | `date_of_nth_sighting()` | Date when cumulative reached threshold |
| 10 | Median by Group | `median_by_group()` | Median sightings by classification |

## How to Run Calculations

### Method 1: Using the Python Script Directly

Run the calculation script from the command line:

```bash
cd "C:/Users/brjul/OneDrive/Documents/Projects/WastesOfTime"
python bigfoot_calculations.py bfro_reports_geocoded.csv --calculation all
```

Available calculation options:
- `all` - Run all 10 calculations
- `streak` - Longest consecutive sighting streak
- `gaps` - Missing report numbers
- `counties` - Cumulative unique counties
- `temp` - Last known temperature
- `nth` - Nth highest state (use `--n 3` for 3rd)
- `pareto` - States for 80% (use `--threshold 0.80`)
- `yoy` - Year-over-year change (use `--year 2010`)
- `cumulative` - Reset running total by decade
- `threshold` - Date of Nth sighting
- `median` - Median by classification

Add `--state "Washington"` to filter by state.

### Method 2: Using Python Interactively

```python
from bigfoot_calculations import BigfootCalculator

calc = BigfootCalculator("bfro_reports_geocoded.csv")

# Run all calculations
results = calc.run_all()

# Or run individual calculations
print(calc.longest_streak())                    # Calculation 1
print(calc.missing_report_numbers())            # Calculation 2
print(calc.cumulative_unique_counties())        # Calculation 3
print(calc.last_known_temperature("2010-01-01"))# Calculation 4
print(calc.nth_highest_state(3))                # Calculation 5
print(calc.pareto_states(0.80))                 # Calculation 6
print(calc.yoy_change(2010))                    # Calculation 7
print(calc.cumulative_reset_by_period('decade'))# Calculation 8
print(calc.date_of_nth_sighting(100))           # Calculation 9
print(calc.median_by_group('classification'))   # Calculation 10
```

## Expected Results Reference

These are the correct answers for the default parameters:

### 1. Longest Consecutive Streak
```
Streak Length: 9 days
Date Range: 2004-11-19 to 2004-11-27
```

### 2. Missing Report Numbers
```
Range: 60 to 58238
Expected: 58,179 numbers
Actual: 4,586 reports
Missing: 53,593 numbers
```

### 3. Cumulative Unique Counties
```
Total Unique Counties: 905 (with date data)
Total Unique Counties: 1,005 (all records)
```

### 4. Last Known Temperature (as of 2010-01-01)
```
Temperature: 53.02 F
Source Date: 2009-12-18 (last date with temperature data before target)
```

### 5. Nth Highest State (N=3)
```
Rank 1: Washington (535 sightings)
Rank 2: California (398 sightings)
Rank 3: Florida (283 sightings)
```

### 6. Pareto 80%
```
States Needed: 22 states
Cumulative: 81.0% of sightings
Top states: Washington, California, Florida, Ohio, Oregon...
```

### 7. Year-over-Year Change (2010)
```
2010 Sightings: 92
2009 Sightings: 115
Change: -23 (-20.0%)
Trend: Down
```

### 8. Cumulative by Decade
```
2000s: Peak cumulative 1,535 sightings
1990s: Peak cumulative 511 sightings
1980s: Peak cumulative 409 sightings
```

### 9. Date of 100th Sighting
```
First Sighting: 1869-11-10
100th Sighting: 1967-08-15
Days to Threshold: 35,706 days (~98 years)
```

### 10. Median Annual Sightings by Classification
```
Class A: 21.0 median sightings per year
Class B: 15.0 median sightings per year
Class C: 1.0 median sightings per year
```

## Troubleshooting DAX Measures

When comparing Python results to DAX results:

1. **Exact match** - DAX is correct
2. **Close but not exact** - Check for:
   - Date filtering differences (inclusive vs exclusive)
   - NULL handling differences
   - Rounding differences
3. **Significantly different** - Check for:
   - Wrong filter context in DAX
   - Missing REMOVEFILTERS or ALL
   - Incorrect relationship direction
   - Context transition issues with CALCULATE

## Common Issues and DAX Fixes

### Streak Calculation Issues
- Ensure date table has no gaps
- Use RANKX with DENSE ranking
- Island detection requires: `Date - RANKX(...)`

### Running Distinct Count Issues
- Must use expanding filter: `DateTable[Date] <= MAX(DateTable[Date])`
- Need REMOVEFILTERS on the column being counted

### Pareto Issues
- EARLIER function needed for cumulative within iteration
- Or use SUMX with FILTER comparing values

### YoY Issues
- DATEADD requires a proper date table marked as date table
- Or use explicit: `DateTable[Year] = CurrentYear - 1`

## Dataset Metadata

```
Total Records: 4,586
Date Range: 1869-11-10 to 2017-09-16
Unique States: 49
Unique Counties: 1,005
Classifications: Class A, Class B, Class C
```
