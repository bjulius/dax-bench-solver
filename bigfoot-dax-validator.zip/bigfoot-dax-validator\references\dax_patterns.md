# DAX Pattern Reference

Detailed explanations of each of the 10 "Easy to See, Hard to DAX" patterns.

## Pattern 1: Consecutive Streak Detection

### The Problem
Find the longest run of consecutive days where at least one event occurred.

### Why It's Hard in DAX
- DAX has no concept of "row order" in the traditional sense
- No native "previous row" function for arbitrary sequences
- Must use ranking gap technique or window functions (OFFSET in newer DAX)

### The Solution: Island Detection

The trick is that consecutive dates, when you subtract their rank, give the same result:

| Date | Rank | Date - Rank |
|------|------|-------------|
| Jan 1 | 1 | Dec 31 (constant!) |
| Jan 2 | 2 | Dec 31 (same!) |
| Jan 3 | 3 | Dec 31 (same!) |
| Jan 5 | 4 | Jan 1 (different - gap!) |
| Jan 6 | 5 | Jan 1 (same!) |

Dates with the same "Date - Rank" value are consecutive. Group by this "island ID" and count.

### DAX Pattern
```dax
VAR DatesWithRank = ADDCOLUMNS(SightingDates, "Rank", RANKX(...))
VAR DatesWithIsland = ADDCOLUMNS(DatesWithRank, "IslandID", [Date] - [Rank])
VAR IslandSizes = GROUPBY(DatesWithIsland, [IslandID], "Count", COUNTX(...))
RETURN MAXX(IslandSizes, [Count])
```

---

## Pattern 2: Gap Detection in Sequences

### The Problem
Find missing values in a sequence (e.g., missing invoice numbers).

### Why It's Hard in DAX
- DAX cannot generate a sequence of "expected" values easily
- No native set difference operation
- Must create reference table or use GENERATESERIES

### The Solution: Generate and Compare

1. Find min and max of actual values
2. Generate complete expected sequence with GENERATESERIES
3. Compare to actual using EXCEPT or count difference

### DAX Pattern
```dax
VAR Expected = GENERATESERIES(MIN([Number]), MAX([Number]), 1)
VAR Actual = DISTINCT(Table[Number])
VAR MissingCount = COUNTROWS(Expected) - COUNTROWS(Actual)
```

---

## Pattern 3: Running Distinct Count

### The Problem
Count unique values cumulatively over time (e.g., unique customers seen up to each date).

### Why It's Hard in DAX
- DISTINCTCOUNT only counts in current filter context
- Need to "expand" the filter to include all prior dates
- Context transition required with CALCULATE

### The Solution: Expanding Date Filter

```dax
VAR CurrentDate = MAX(DateTable[Date])
RETURN CALCULATE(
    DISTINCTCOUNT(Table[Column]),
    FILTER(ALL(DateTable), DateTable[Date] <= CurrentDate),
    REMOVEFILTERS(Table[Column])  -- Important!
)
```

The REMOVEFILTERS ensures you're counting distinct values across all rows up to the current date, not just rows matching other current filters.

---

## Pattern 4: Previous Non-Blank Value

### The Problem
If the current value is blank, show the last known value from a previous date.

### Why It's Hard in DAX
- DAX doesn't "look up" to previous rows
- Must find the maximum date where value wasn't blank
- Then retrieve that specific value

### The Solution: Two-Step Lookup

```dax
VAR LastKnownDate = CALCULATE(
    MAX(Table[Date]),
    FILTER(ALL(Table), Table[Date] <= CurrentDate && NOT(ISBLANK(Table[Value])))
)
VAR LastKnownValue = CALCULATE(
    VALUES(Table[Value]),
    Table[Date] = LastKnownDate
)
```

---

## Pattern 5: Nth Highest Value

### The Problem
Find the value at a specific rank position (3rd highest, 5th lowest, etc.).

### Why It's Hard in DAX
- Cannot simply index into a sorted list
- TOPN returns a table, not a single value
- Must combine TOPN with MIN/MAX or use RANKX with filtering

### The Solution: TOPN + Boundary Value

```dax
-- For 3rd highest:
VAR Top3 = TOPN(3, ALL(Table), [Value], DESC)
RETURN MINX(Top3, [Value])  -- Smallest of top 3 = the 3rd highest
```

Or with RANKX:
```dax
VAR Ranked = ADDCOLUMNS(Table, "Rank", RANKX(ALL(Table), [Value], , DESC))
RETURN MAXX(FILTER(Ranked, [Rank] = 3), [Value])
```

---

## Pattern 6: Pareto Analysis (80% Threshold)

### The Problem
Find how many items account for X% of the total.

### Why It's Hard in DAX
- Need cumulative percentage
- Must reference "all items ranked higher" from within each row
- EARLIER function or nested iteration required

### The Solution: Running Sum with EARLIER

```dax
VAR Ranked = ADDCOLUMNS(Table, "Pct", [Value] / Total)
VAR WithCumulative = ADDCOLUMNS(Ranked,
    "CumPct", SUMX(FILTER(Ranked, [Value] >= EARLIER([Value])), [Pct])
)
RETURN MINX(FILTER(WithCumulative, [CumPct] >= 0.80), [Rank])
```

---

## Pattern 7: Previous Period Comparison

### The Problem
Compare current period to the same period in the prior year/month.

### Why It's Hard in DAX
- No "previous row" concept
- Must explicitly calculate the prior period's value
- Time intelligence functions require proper date table setup

### The Solution: Explicit Period Reference

```dax
VAR CurrentYear = SELECTEDVALUE(DateTable[Year])
VAR CurrentValue = [Measure]
VAR PriorValue = CALCULATE([Measure], DateTable[Year] = CurrentYear - 1)
RETURN CurrentValue - PriorValue
```

Or with time intelligence (requires marked date table):
```dax
VAR PriorValue = CALCULATE([Measure], DATEADD(DateTable[Date], -1, YEAR))
```

---

## Pattern 8: Running Total with Reset

### The Problem
Calculate a running total that resets at period boundaries (each year, quarter, etc.).

### Why It's Hard in DAX
- DAX has no persistent "state" between row evaluations
- Must filter to both:
  - Current period (for reset)
  - Dates up to current date (for running total)

### The Solution: Dual Filter

```dax
VAR CurrentDate = MAX(DateTable[Date])
VAR CurrentPeriod = MAX(DateTable[Year])  -- or Decade, Quarter, etc.
RETURN CALCULATE(
    [Measure],
    FILTER(ALL(DateTable),
        DateTable[Year] = CurrentPeriod &&
        DateTable[Date] <= CurrentDate
    )
)
```

---

## Pattern 9: First Date Meeting Condition

### The Problem
Find when a cumulative value first reached a threshold.

### Why It's Hard in DAX
- Must calculate running total for EVERY date
- Then find the MINIMUM date where running total >= threshold
- Requires nested calculation

### The Solution: Generate Cumulative, Filter, Find Min

```dax
VAR DatesWithCumulative = ADDCOLUMNS(
    VALUES(DateTable[Date]),
    "Cumulative", VAR ThisDate = [Date]
    RETURN CALCULATE([Measure], DateTable[Date] <= ThisDate)
)
VAR FirstOverThreshold = MINX(
    FILTER(DatesWithCumulative, [Cumulative] >= Threshold),
    [Date]
)
```

---

## Pattern 10: Median Per Group

### The Problem
Calculate median of a metric for each category in a visual.

### Why It's Hard in DAX
- MEDIANX exists but evaluates in current filter context
- In matrix visuals, context can be confusing
- Must explicitly control what you're taking median OF

### The Solution: Explicit Aggregation First

```dax
-- Median of annual counts:
VAR YearlyCounts = ADDCOLUMNS(
    VALUES(DateTable[Year]),
    "Count", CALCULATE(COUNTROWS(Table))
)
RETURN MEDIANX(YearlyCounts, [Count])
```

The key is using ADDCOLUMNS to first create a table at the right grain (years), then taking median of that table.

---

## Summary of Key DAX Techniques

| Pattern | Key Technique |
|---------|---------------|
| Streak | RANKX gap detection |
| Gaps | GENERATESERIES + set comparison |
| Running Distinct | Expanding CALCULATE filter |
| Last Known | Double CALCULATE with MAX date |
| Nth Value | TOPN + boundary or RANKX + filter |
| Pareto | EARLIER for cumulative % |
| Period Compare | Explicit year math or DATEADD |
| Reset Total | Dual filter (period + date range) |
| Threshold | Nested ADDCOLUMNS + MINX |
| Median | ADDCOLUMNS to control grain |
